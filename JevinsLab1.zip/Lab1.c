//Jevin Wilson
//303384
#include <stdio.h>

int main(int argc, char** argv)
{
    printf("  /-\\ \n /\"\"\"\\ \n/\"\"\"\"\"\\ \n");
    printf("|Jevin| \n");
    printf("\\\"\"\"\"\"/ \n \\\"\"\"/  \n  \\-/  \n");
    //printf("  \\-/   \n");
}